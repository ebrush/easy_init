from easy_init.easy_init import init
